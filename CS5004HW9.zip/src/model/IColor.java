package model;

public interface IColor {
  IColor getColor();
  int getR();
  int getG();
  int getB();
}
